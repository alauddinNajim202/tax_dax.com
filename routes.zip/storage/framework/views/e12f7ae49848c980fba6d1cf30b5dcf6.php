<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <!-- css -->
    <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/plugins/bootstrap.min.css')); ?>">
    <!-- <link rel="stylesheet" href="./assets/css/common/common.css"> -->
    <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/dashboard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/calendar.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/tDashboard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/common/table.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/common/client-common.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/common/common.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/categories.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/plugins/nice-select.min.css')); ?> ">

     <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/profile.css')); ?> ">

     <link rel="stylesheet" href="<?php echo e(asset('user_dashboard/assets/css/rate-type.css')); ?>">


</head>

<body>
    <!-- header start -->
        <?php echo $__env->make('user_dashboard.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- header end -->

    <div class="main-container">


        <!-- sidebar start -->
            <?php echo $__env->make('user_dashboard.partials.sidebar_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- sidebar end -->



        <!-- main-container start -->
            <?php echo $__env->yieldContent('user_dashboard_content'); ?>
        <!-- main-container end -->


        <!-- script js -->
        <?php echo $__env->make('user_dashboard.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\tax_dax.com\resources\views/user_dashboard/app.blade.php ENDPATH**/ ?>