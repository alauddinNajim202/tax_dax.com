
<script src="<?php echo e(asset('backend/assets/custom_downloaded_file/axios.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/custom_downloaded_file/moment.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/plugins/jquery/jquery.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/plugins/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/plugins/sidemenu/sidemenu.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/plugins/p-scroll/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/p-scroll/pscroll.js')); ?>"></script>


<script src="<?php echo e(asset('backend/js/sticky.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/plugins/summernote-editor/summernote1.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/summernote.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/js/dropify.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/js/toastr.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/js/dataTables.bootstrap5.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/js/butsns.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/js/butsns.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/js/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/datatable/responsive.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/table-data.js')); ?>"></script>


<script src="<?php echo e(asset('backend/js/apexcharts.js')); ?>"></script>


<script src="<?php echo e(asset('backend/plugins/select2/select2.full.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/plugins/circle-progress/circle-progress.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/js/index1.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/index.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/js/reply.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/js/themeColors.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/js/custom.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/switcher/js/switcher.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/js/sweetalert2@11.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/custom_downloaded_file/ckeditor.js')); ?>"></script>


<script>
    $(document).ready(function() {
        toastr.options.timeOut = 10000;
        toastr.options.positionClass = 'toast-top-right';

        <?php if(Session::has('t-success')): ?>
            toastr.options = {
                'closeButton': true,
                'debug': false,
                'newestOnTop': true,
                'progressBar': true,
                'positionClass': 'toast-top-right',
                'preventDuplicates': false,
                'showDuration': '1000',
                'hideDuration': '1000',
                'timeOut': '5000',
                'extendedTimeOut': '1000',
                'showEasing': 'swing',
                'hideEasing': 'linear',
                'showMethod': 'fadeIn',
                'hideMethod': 'fadeOut',
            };
            toastr.success("<?php echo e(session('t-success')); ?>");
        <?php endif; ?>

        <?php if(Session::has('t-error')): ?>
            toastr.options = {
                'closeButton': true,
                'debug': false,
                'newestOnTop': true,
                'progressBar': true,
                'positionClass': 'toast-top-right',
                'preventDuplicates': false,
                'showDuration': '1000',
                'hideDuration': '1000',
                'timeOut': '5000',
                'extendedTimeOut': '1000',
                'showEasing': 'swing',
                'hideEasing': 'linear',
                'showMethod': 'fadeIn',
                'hideMethod': 'fadeOut',
            };
            toastr.error("<?php echo e(session('t-error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('t-info')): ?>
            toastr.options = {
                'closeButton': true,
                'debug': false,
                'newestOnTop': true,
                'progressBar': true,
                'positionClass': 'toast-top-right',
                'preventDuplicates': false,
                'showDuration': '1000',
                'hideDuration': '1000',
                'timeOut': '5000',
                'extendedTimeOut': '1000',
                'showEasing': 'swing',
                'hideEasing': 'linear',
                'showMethod': 'fadeIn',
                'hideMethod': 'fadeOut',
            };
            toastr.info("<?php echo e(session('t-info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('t-warning')): ?>
            toastr.options = {
                'closeButton': true,
                'debug': false,
                'newestOnTop': true,
                'progressBar': true,
                'positionClass': 'toast-top-right',
                'preventDuplicates': false,
                'showDuration': '1000',
                'hideDuration': '1000',
                'timeOut': '5000',
                'extendedTimeOut': '1000',
                'showEasing': 'swing',
                'hideEasing': 'linear',
                'showMethod': 'fadeIn',
                'hideMethod': 'fadeOut',
            };
            toastr.warning("<?php echo e(session('t-warning')); ?>");
        <?php endif; ?>
    });
</script>



<script>
    $(document).ready(function() {
        $('.dropify').dropify();
    });
</script>



<script>
    $(document).ready(function() {
        $('#summernote').summernote({
            tabsize: 2,
            height: 220,
        });
    });
</script>


<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\laragon\www\tax_dax.com\resources\views/backend/partials/scripts.blade.php ENDPATH**/ ?>