<?php $__env->startSection('title', 'Social Media Settings'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .drop-custom {
            border-top-left-radius: 6px;
            border-bottom-left-radius: 6px;
            padding: 15px;
            border: 1px solid #4CAF50;
            color: #313131;
            transition: all 0.3s ease;
        }

        .drop-custom:hover {
            background-color: #414241;
            color: white;
        }

        .btn {
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: scale(1.1);
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-header">
        <div>
            <h1 class="page-title">Social Media Settings</h1>
        </div>
        <div class="ms-auto pageheader-btn">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0);">Settings</a></li>
                <li class="breadcrumb-item active" aria-current="page">Social Media Settings</li>
            </ol>
        </div>
    </div>
    

    <div class="row">
        <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
            <div class="card box-shadow-0">
                <div class="card-body">
                    <form action="<?php echo e(route('social.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div style="display: flex; justify-content: end; margin-bottom: 10px;">
                            <button class="btn btn-outline-secondary" type="button" onclick="addSocialField()"
                                style="font-weight: 900" title="Add a new social media field">Add</button>
                        </div>
                        <div id="social_media_container">
                            <?php $__currentLoopData = $social_link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="social_media input-group mb-3 dropdown">
                                    <input type="hidden" name="social_media_id[]" value="<?php echo e($link->id); ?>">
                                    <select class="dropdown-toggle drop-custom" name="social_media[]"
                                        value="<?php if(isset($social_link)): ?><?php echo e($link->social_media); ?><?php endif; ?>"
                                        title="Select a social media platform">
                                        <option class="dropdown-item">Select Social</option>
                                        <option class="dropdown-item" value="facebook"
                                            <?php echo e($link->social_media == 'facebook' ? 'selected' : ''); ?>>Facebook
                                        </option>
                                        <option class="dropdown-item" value="instagram"
                                            <?php echo e($link->social_media == 'instagram' ? 'selected' : ''); ?>>Instagram
                                        </option>
                                        <option class="dropdown-item" value="twitter"
                                            <?php echo e($link->social_media == 'twitter' ? 'selected' : ''); ?>>Twitter
                                        </option>
                                        <option class="dropdown-item" value="tiktok"
                                            <?php echo e($link->social_media == 'tiktok' ? 'selected' : ''); ?>>Tiktok
                                        </option>
                                        <option class="dropdown-item" value="youtube"
                                            <?php echo e($link->social_media == 'youtube' ? 'selected' : ''); ?>>YouTube
                                        </option>
                                        <option class="dropdown-item" value="linkedin"
                                            <?php echo e($link->social_media == 'linkedin' ? 'selected' : ''); ?>>Linkedin
                                        </option>
                                    </select>
                                    <input type="url" class="form-control" aria-label="Text input with dropdown button"
                                        name="profile_link[]"
                                        value="<?php if(isset($social_link)): ?><?php echo e($link->profile_link); ?><?php endif; ?>"
                                        placeholder="Enter the profile link here" title="Enter the profile link here">
                                    <button class="btn btn-outline-secondary removeSocialBtn" type="button"
                                        onclick="removeSocialField(this)" style="font-weight: 900"
                                        data-id="<?php echo e($link->id); ?>"
                                        title="Remove this social media field">Remove</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="col-12">
                            <button type="submit" class="btn btn-primary" title="Submit the form">Submit</button>
                            <a href="<?php echo e(route('admin.index')); ?>" class="btn btn-danger me-2"
                                title="Cancel and go back to the dashboard">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        let socialFieldsCount = $('#social_media_container .social_media').length;

        function addSocialField() {
            const socialFieldsContainer = document.getElementById("social_media_container");

            if (socialFieldsCount < 6) {
                const newSocialField = document.createElement("div");
                newSocialField.className = "social_media input-group mb-3";
                newSocialField.innerHTML =
                    `
            <select class="dropdown-toggle drop-custom" name="social_media[]" title="Select a social media platform">
                <option class="dropdown-item">Select Social</option>
                <option class="dropdown-item" value="facebook">Facebook</option>
                <option class="dropdown-item" value="instagram">Instagram</option>
                <option class="dropdown-item" value="twitter">Twitter</option>
                <option class="dropdown-item" value="tiktok">Tiktok</option>
                <option class="dropdown-item" value="youtube">YouTube</option>
                <option class="dropdown-item" value="linkedin">Linkedin</option>
            </select>
            <input type="url" class="form-control" aria-label="Text input with dropdown button" name="profile_link[]" placeholder="Enter the profile link here" title="Enter the profile link here">
            <button class="btn btn-outline-secondary" type="button" onclick="removeSocialField(this)" style="font-weight: 900" title="Remove this social media field">Remove</button>`;

                socialFieldsContainer.appendChild(newSocialField);
                socialFieldsCount++;
                document.querySelectorAll('select[name="social_media[]"]').forEach(selectElement => {
                    selectElement.removeEventListener('change', checkForDuplicateSocialMedia);
                    selectElement.addEventListener('change', checkForDuplicateSocialMedia);
                });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "You can only add six social links fields!",
                });
            }
        }

        function removeSocialField(button) {
            const socialField = button.parentElement;
            socialField.remove();
            socialFieldsCount--;
            checkForDuplicateSocialMedia();
        }

        function checkForDuplicateSocialMedia() {
            const allSelections = document.querySelectorAll('select[name="social_media[]"]');
            const allValues = Array.from(allSelections).map(select => select.value);
            const hasDuplicate = allValues.some((value, index) => allValues.indexOf(value) !== index && value !==
                "Select Social");

            if (hasDuplicate) {
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "You cannot add the same social media platform more than once.",
                });
                allSelections.forEach(selectElement => {
                    if (allValues.filter(value => value === selectElement.value).length > 1) {
                        selectElement.value = "Select Social";
                    }
                });
            }
        }

        window.removeSocialField = function(button) {
            const socialLinkId = $(button).data('id');

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'DELETE',
                url: '<?php echo e(route('social.delete', '')); ?>/' + socialLinkId,
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    $(button).closest('.social_media').remove();
                    socialFieldsCount--;
                    if (response.success === true) {
                        toastr.success(response.message);
                    } else if (response.errors) {
                        toastr.error(response.errors[0]);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Something went wrong. Please try again.",
                    });
                }
            });
        };

        document.querySelectorAll('select[name="social_media[]"]').forEach(selectElement => {
            selectElement.addEventListener('change', checkForDuplicateSocialMedia);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tax_dax.com\resources\views/backend/layouts/settings/social_media.blade.php ENDPATH**/ ?>