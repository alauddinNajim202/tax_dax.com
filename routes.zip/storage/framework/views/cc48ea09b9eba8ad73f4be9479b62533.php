<?php $__env->startSection('user_dashboard_content'); ?>
<div class="main-content">
    <!-- mobile searchbar start -->
    <!-- search bar start -->
    <div class="mobile-search-bar mb-3">
        <div class="left">
            <input id="searchBarMobile" class="search-input" placeholder="Search..." value=""
                type="text" />
            <div class="search-list">
                <div class="search-item">London, Uk</div>
                <div class="search-item">Tokyo, Jp</div>
                <div class="search-item">Paris, Fr</div>
                <div class="search-item">Sydney, Au</div>
                <div class="search-item">Berlin, De</div>
                <div class="search-item">Toronto, Ca</div>
                <div class="search-item">Moscow, Ru</div>
                <div class="search-item">Mumbai, In</div>
                <div class="search-item">London, Uk</div>
                <div class="search-item">Tokyo, Jp</div>
                <div class="search-item">Paris, Fr</div>
                <div class="search-item">Sydney, Au</div>
                <div class="search-item">Berlin, De</div>
                <div class="search-item">Toronto, Ca</div>
                <div class="search-item">Moscow, Ru</div>
                <div class="search-item">Mumbai, In</div>
            </div>
        </div>
        <div class="right">
            <svg width="16px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                <path
                    d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z" />
            </svg>
        </div>
    </div>
    <!-- search bar end -->
    <!-- mobile searchbar end -->
    <div class="data-table table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Document Name</th>
                    <th scope="col">Category</th>
                    <th scope="col">Upload Date</th>
                    <th scope="col">Sent By / Sent To</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>W-2_2023.pdf</td>
                    <td>Uploaded by You</td>
                    <td>Jan 15, 2024</td>
                    <td>Sent to: <span class="active-text">John Doe, CPA</span></td>
                    <td>
                        <div class="action-container">
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M12.4987 14.9168C14.1095 14.9168 15.4154 13.611 15.4154 12.0002C15.4154 10.3893 14.1095 9.0835 12.4987 9.0835C10.8879 9.0835 9.58203 10.3893 9.58203 12.0002C9.58203 13.611 10.8879 14.9168 12.4987 14.9168Z"
                                        stroke="#6B6B6B" />
                                    <path
                                        d="M19.3231 11.1117C19.6464 11.505 19.8081 11.7008 19.8081 12C19.8081 12.2992 19.6464 12.495 19.3231 12.8883C18.1397 14.325 15.5297 17 12.4997 17C9.46974 17 6.85974 14.325 5.67641 12.8883C5.35307 12.495 5.19141 12.2992 5.19141 12C5.19141 11.7008 5.35307 11.505 5.67641 11.1117C6.85974 9.675 9.46974 7 12.4997 7C15.5297 7 18.1397 9.675 19.3231 11.1117Z"
                                        stroke="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action download-action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="14"
                                    viewBox="0 0 13 14" fill="none">
                                    <path
                                        d="M6.5 10.25L2.4375 6.1875L3.575 5.00937L5.6875 7.12187V0.5H7.3125V7.12187L9.425 5.00937L10.5625 6.1875L6.5 10.25ZM1.625 13.5C1.17813 13.5 0.795708 13.341 0.47775 13.0231C0.159792 12.7051 0.000541667 12.3224 0 11.875V9.4375H1.625V11.875H11.375V9.4375H13V11.875C13 12.3219 12.841 12.7046 12.5231 13.0231C12.2051 13.3416 11.8224 13.5005 11.375 13.5H1.625Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M9.0625 18C8.68438 18 8.36079 17.8696 8.09175 17.6087C7.82271 17.3478 7.68796 17.0338 7.6875 16.6667V8H7V6.66667H10.4375V6H14.5625V6.66667H18V8H17.3125V16.6667C17.3125 17.0333 17.178 17.3473 16.9089 17.6087C16.6399 17.87 16.3161 18.0004 15.9375 18H9.0625ZM15.9375 8H9.0625V16.6667H15.9375V8ZM10.4375 15.3333H11.8125V9.33333H10.4375V15.3333ZM13.1875 15.3333H14.5625V9.33333H13.1875V15.3333Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>W-2_2023.pdf</td>
                    <td>Uploaded by You</td>
                    <td>Jan 15, 2024</td>
                    <td>Sent to: <span class="active-text">John Doe, CPA</span></td>
                    <td>
                        <div class="action-container">
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M12.4987 14.9168C14.1095 14.9168 15.4154 13.611 15.4154 12.0002C15.4154 10.3893 14.1095 9.0835 12.4987 9.0835C10.8879 9.0835 9.58203 10.3893 9.58203 12.0002C9.58203 13.611 10.8879 14.9168 12.4987 14.9168Z"
                                        stroke="#6B6B6B" />
                                    <path
                                        d="M19.3231 11.1117C19.6464 11.505 19.8081 11.7008 19.8081 12C19.8081 12.2992 19.6464 12.495 19.3231 12.8883C18.1397 14.325 15.5297 17 12.4997 17C9.46974 17 6.85974 14.325 5.67641 12.8883C5.35307 12.495 5.19141 12.2992 5.19141 12C5.19141 11.7008 5.35307 11.505 5.67641 11.1117C6.85974 9.675 9.46974 7 12.4997 7C15.5297 7 18.1397 9.675 19.3231 11.1117Z"
                                        stroke="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action download-action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="14"
                                    viewBox="0 0 13 14" fill="none">
                                    <path
                                        d="M6.5 10.25L2.4375 6.1875L3.575 5.00937L5.6875 7.12187V0.5H7.3125V7.12187L9.425 5.00937L10.5625 6.1875L6.5 10.25ZM1.625 13.5C1.17813 13.5 0.795708 13.341 0.47775 13.0231C0.159792 12.7051 0.000541667 12.3224 0 11.875V9.4375H1.625V11.875H11.375V9.4375H13V11.875C13 12.3219 12.841 12.7046 12.5231 13.0231C12.2051 13.3416 11.8224 13.5005 11.375 13.5H1.625Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M9.0625 18C8.68438 18 8.36079 17.8696 8.09175 17.6087C7.82271 17.3478 7.68796 17.0338 7.6875 16.6667V8H7V6.66667H10.4375V6H14.5625V6.66667H18V8H17.3125V16.6667C17.3125 17.0333 17.178 17.3473 16.9089 17.6087C16.6399 17.87 16.3161 18.0004 15.9375 18H9.0625ZM15.9375 8H9.0625V16.6667H15.9375V8ZM10.4375 15.3333H11.8125V9.33333H10.4375V15.3333ZM13.1875 15.3333H14.5625V9.33333H13.1875V15.3333Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>W-2_2023.pdf</td>
                    <td>Uploaded by You</td>
                    <td>Jan 15, 2024</td>
                    <td>Sent to: <span class="active-text">John Doe, CPA</span></td>
                    <td>
                        <div class="action-container">
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M12.4987 14.9168C14.1095 14.9168 15.4154 13.611 15.4154 12.0002C15.4154 10.3893 14.1095 9.0835 12.4987 9.0835C10.8879 9.0835 9.58203 10.3893 9.58203 12.0002C9.58203 13.611 10.8879 14.9168 12.4987 14.9168Z"
                                        stroke="#6B6B6B" />
                                    <path
                                        d="M19.3231 11.1117C19.6464 11.505 19.8081 11.7008 19.8081 12C19.8081 12.2992 19.6464 12.495 19.3231 12.8883C18.1397 14.325 15.5297 17 12.4997 17C9.46974 17 6.85974 14.325 5.67641 12.8883C5.35307 12.495 5.19141 12.2992 5.19141 12C5.19141 11.7008 5.35307 11.505 5.67641 11.1117C6.85974 9.675 9.46974 7 12.4997 7C15.5297 7 18.1397 9.675 19.3231 11.1117Z"
                                        stroke="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action download-action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="14"
                                    viewBox="0 0 13 14" fill="none">
                                    <path
                                        d="M6.5 10.25L2.4375 6.1875L3.575 5.00937L5.6875 7.12187V0.5H7.3125V7.12187L9.425 5.00937L10.5625 6.1875L6.5 10.25ZM1.625 13.5C1.17813 13.5 0.795708 13.341 0.47775 13.0231C0.159792 12.7051 0.000541667 12.3224 0 11.875V9.4375H1.625V11.875H11.375V9.4375H13V11.875C13 12.3219 12.841 12.7046 12.5231 13.0231C12.2051 13.3416 11.8224 13.5005 11.375 13.5H1.625Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M9.0625 18C8.68438 18 8.36079 17.8696 8.09175 17.6087C7.82271 17.3478 7.68796 17.0338 7.6875 16.6667V8H7V6.66667H10.4375V6H14.5625V6.66667H18V8H17.3125V16.6667C17.3125 17.0333 17.178 17.3473 16.9089 17.6087C16.6399 17.87 16.3161 18.0004 15.9375 18H9.0625ZM15.9375 8H9.0625V16.6667H15.9375V8ZM10.4375 15.3333H11.8125V9.33333H10.4375V15.3333ZM13.1875 15.3333H14.5625V9.33333H13.1875V15.3333Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>W-2_2023.pdf</td>
                    <td>Uploaded by You</td>
                    <td>Jan 15, 2024</td>
                    <td>Sent to: <span class="active-text">John Doe, CPA</span></td>
                    <td>
                        <div class="action-container">
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M12.4987 14.9168C14.1095 14.9168 15.4154 13.611 15.4154 12.0002C15.4154 10.3893 14.1095 9.0835 12.4987 9.0835C10.8879 9.0835 9.58203 10.3893 9.58203 12.0002C9.58203 13.611 10.8879 14.9168 12.4987 14.9168Z"
                                        stroke="#6B6B6B" />
                                    <path
                                        d="M19.3231 11.1117C19.6464 11.505 19.8081 11.7008 19.8081 12C19.8081 12.2992 19.6464 12.495 19.3231 12.8883C18.1397 14.325 15.5297 17 12.4997 17C9.46974 17 6.85974 14.325 5.67641 12.8883C5.35307 12.495 5.19141 12.2992 5.19141 12C5.19141 11.7008 5.35307 11.505 5.67641 11.1117C6.85974 9.675 9.46974 7 12.4997 7C15.5297 7 18.1397 9.675 19.3231 11.1117Z"
                                        stroke="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action download-action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="14"
                                    viewBox="0 0 13 14" fill="none">
                                    <path
                                        d="M6.5 10.25L2.4375 6.1875L3.575 5.00937L5.6875 7.12187V0.5H7.3125V7.12187L9.425 5.00937L10.5625 6.1875L6.5 10.25ZM1.625 13.5C1.17813 13.5 0.795708 13.341 0.47775 13.0231C0.159792 12.7051 0.000541667 12.3224 0 11.875V9.4375H1.625V11.875H11.375V9.4375H13V11.875C13 12.3219 12.841 12.7046 12.5231 13.0231C12.2051 13.3416 11.8224 13.5005 11.375 13.5H1.625Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M9.0625 18C8.68438 18 8.36079 17.8696 8.09175 17.6087C7.82271 17.3478 7.68796 17.0338 7.6875 16.6667V8H7V6.66667H10.4375V6H14.5625V6.66667H18V8H17.3125V16.6667C17.3125 17.0333 17.178 17.3473 16.9089 17.6087C16.6399 17.87 16.3161 18.0004 15.9375 18H9.0625ZM15.9375 8H9.0625V16.6667H15.9375V8ZM10.4375 15.3333H11.8125V9.33333H10.4375V15.3333ZM13.1875 15.3333H14.5625V9.33333H13.1875V15.3333Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>W-2_2023.pdf</td>
                    <td>Uploaded by You</td>
                    <td>Jan 15, 2024</td>
                    <td>Sent to: <span class="active-text">John Doe, CPA</span></td>
                    <td>
                        <div class="action-container">
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M12.4987 14.9168C14.1095 14.9168 15.4154 13.611 15.4154 12.0002C15.4154 10.3893 14.1095 9.0835 12.4987 9.0835C10.8879 9.0835 9.58203 10.3893 9.58203 12.0002C9.58203 13.611 10.8879 14.9168 12.4987 14.9168Z"
                                        stroke="#6B6B6B" />
                                    <path
                                        d="M19.3231 11.1117C19.6464 11.505 19.8081 11.7008 19.8081 12C19.8081 12.2992 19.6464 12.495 19.3231 12.8883C18.1397 14.325 15.5297 17 12.4997 17C9.46974 17 6.85974 14.325 5.67641 12.8883C5.35307 12.495 5.19141 12.2992 5.19141 12C5.19141 11.7008 5.35307 11.505 5.67641 11.1117C6.85974 9.675 9.46974 7 12.4997 7C15.5297 7 18.1397 9.675 19.3231 11.1117Z"
                                        stroke="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action download-action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="14"
                                    viewBox="0 0 13 14" fill="none">
                                    <path
                                        d="M6.5 10.25L2.4375 6.1875L3.575 5.00937L5.6875 7.12187V0.5H7.3125V7.12187L9.425 5.00937L10.5625 6.1875L6.5 10.25ZM1.625 13.5C1.17813 13.5 0.795708 13.341 0.47775 13.0231C0.159792 12.7051 0.000541667 12.3224 0 11.875V9.4375H1.625V11.875H11.375V9.4375H13V11.875C13 12.3219 12.841 12.7046 12.5231 13.0231C12.2051 13.3416 11.8224 13.5005 11.375 13.5H1.625Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M9.0625 18C8.68438 18 8.36079 17.8696 8.09175 17.6087C7.82271 17.3478 7.68796 17.0338 7.6875 16.6667V8H7V6.66667H10.4375V6H14.5625V6.66667H18V8H17.3125V16.6667C17.3125 17.0333 17.178 17.3473 16.9089 17.6087C16.6399 17.87 16.3161 18.0004 15.9375 18H9.0625ZM15.9375 8H9.0625V16.6667H15.9375V8ZM10.4375 15.3333H11.8125V9.33333H10.4375V15.3333ZM13.1875 15.3333H14.5625V9.33333H13.1875V15.3333Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>W-2_2023.pdf</td>
                    <td>Uploaded by You</td>
                    <td>Jan 15, 2024</td>
                    <td>Sent to: <span class="active-text">John Doe, CPA</span></td>
                    <td>
                        <div class="action-container">
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M12.4987 14.9168C14.1095 14.9168 15.4154 13.611 15.4154 12.0002C15.4154 10.3893 14.1095 9.0835 12.4987 9.0835C10.8879 9.0835 9.58203 10.3893 9.58203 12.0002C9.58203 13.611 10.8879 14.9168 12.4987 14.9168Z"
                                        stroke="#6B6B6B" />
                                    <path
                                        d="M19.3231 11.1117C19.6464 11.505 19.8081 11.7008 19.8081 12C19.8081 12.2992 19.6464 12.495 19.3231 12.8883C18.1397 14.325 15.5297 17 12.4997 17C9.46974 17 6.85974 14.325 5.67641 12.8883C5.35307 12.495 5.19141 12.2992 5.19141 12C5.19141 11.7008 5.35307 11.505 5.67641 11.1117C6.85974 9.675 9.46974 7 12.4997 7C15.5297 7 18.1397 9.675 19.3231 11.1117Z"
                                        stroke="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action download-action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="14"
                                    viewBox="0 0 13 14" fill="none">
                                    <path
                                        d="M6.5 10.25L2.4375 6.1875L3.575 5.00937L5.6875 7.12187V0.5H7.3125V7.12187L9.425 5.00937L10.5625 6.1875L6.5 10.25ZM1.625 13.5C1.17813 13.5 0.795708 13.341 0.47775 13.0231C0.159792 12.7051 0.000541667 12.3224 0 11.875V9.4375H1.625V11.875H11.375V9.4375H13V11.875C13 12.3219 12.841 12.7046 12.5231 13.0231C12.2051 13.3416 11.8224 13.5005 11.375 13.5H1.625Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M9.0625 18C8.68438 18 8.36079 17.8696 8.09175 17.6087C7.82271 17.3478 7.68796 17.0338 7.6875 16.6667V8H7V6.66667H10.4375V6H14.5625V6.66667H18V8H17.3125V16.6667C17.3125 17.0333 17.178 17.3473 16.9089 17.6087C16.6399 17.87 16.3161 18.0004 15.9375 18H9.0625ZM15.9375 8H9.0625V16.6667H15.9375V8ZM10.4375 15.3333H11.8125V9.33333H10.4375V15.3333ZM13.1875 15.3333H14.5625V9.33333H13.1875V15.3333Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>W-2_2023.pdf</td>
                    <td>Uploaded by You</td>
                    <td>Jan 15, 2024</td>
                    <td>Sent to: <span class="active-text">John Doe, CPA</span></td>
                    <td>
                        <div class="action-container">
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M12.4987 14.9168C14.1095 14.9168 15.4154 13.611 15.4154 12.0002C15.4154 10.3893 14.1095 9.0835 12.4987 9.0835C10.8879 9.0835 9.58203 10.3893 9.58203 12.0002C9.58203 13.611 10.8879 14.9168 12.4987 14.9168Z"
                                        stroke="#6B6B6B" />
                                    <path
                                        d="M19.3231 11.1117C19.6464 11.505 19.8081 11.7008 19.8081 12C19.8081 12.2992 19.6464 12.495 19.3231 12.8883C18.1397 14.325 15.5297 17 12.4997 17C9.46974 17 6.85974 14.325 5.67641 12.8883C5.35307 12.495 5.19141 12.2992 5.19141 12C5.19141 11.7008 5.35307 11.505 5.67641 11.1117C6.85974 9.675 9.46974 7 12.4997 7C15.5297 7 18.1397 9.675 19.3231 11.1117Z"
                                        stroke="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action download-action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="14"
                                    viewBox="0 0 13 14" fill="none">
                                    <path
                                        d="M6.5 10.25L2.4375 6.1875L3.575 5.00937L5.6875 7.12187V0.5H7.3125V7.12187L9.425 5.00937L10.5625 6.1875L6.5 10.25ZM1.625 13.5C1.17813 13.5 0.795708 13.341 0.47775 13.0231C0.159792 12.7051 0.000541667 12.3224 0 11.875V9.4375H1.625V11.875H11.375V9.4375H13V11.875C13 12.3219 12.841 12.7046 12.5231 13.0231C12.2051 13.3416 11.8224 13.5005 11.375 13.5H1.625Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M9.0625 18C8.68438 18 8.36079 17.8696 8.09175 17.6087C7.82271 17.3478 7.68796 17.0338 7.6875 16.6667V8H7V6.66667H10.4375V6H14.5625V6.66667H18V8H17.3125V16.6667C17.3125 17.0333 17.178 17.3473 16.9089 17.6087C16.6399 17.87 16.3161 18.0004 15.9375 18H9.0625ZM15.9375 8H9.0625V16.6667H15.9375V8ZM10.4375 15.3333H11.8125V9.33333H10.4375V15.3333ZM13.1875 15.3333H14.5625V9.33333H13.1875V15.3333Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>W-2_2023.pdf</td>
                    <td>Uploaded by You</td>
                    <td>Jan 15, 2024</td>
                    <td>Sent to: <span class="active-text">John Doe, CPA</span></td>
                    <td>
                        <div class="action-container">
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M12.4987 14.9168C14.1095 14.9168 15.4154 13.611 15.4154 12.0002C15.4154 10.3893 14.1095 9.0835 12.4987 9.0835C10.8879 9.0835 9.58203 10.3893 9.58203 12.0002C9.58203 13.611 10.8879 14.9168 12.4987 14.9168Z"
                                        stroke="#6B6B6B" />
                                    <path
                                        d="M19.3231 11.1117C19.6464 11.505 19.8081 11.7008 19.8081 12C19.8081 12.2992 19.6464 12.495 19.3231 12.8883C18.1397 14.325 15.5297 17 12.4997 17C9.46974 17 6.85974 14.325 5.67641 12.8883C5.35307 12.495 5.19141 12.2992 5.19141 12C5.19141 11.7008 5.35307 11.505 5.67641 11.1117C6.85974 9.675 9.46974 7 12.4997 7C15.5297 7 18.1397 9.675 19.3231 11.1117Z"
                                        stroke="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action download-action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="14"
                                    viewBox="0 0 13 14" fill="none">
                                    <path
                                        d="M6.5 10.25L2.4375 6.1875L3.575 5.00937L5.6875 7.12187V0.5H7.3125V7.12187L9.425 5.00937L10.5625 6.1875L6.5 10.25ZM1.625 13.5C1.17813 13.5 0.795708 13.341 0.47775 13.0231C0.159792 12.7051 0.000541667 12.3224 0 11.875V9.4375H1.625V11.875H11.375V9.4375H13V11.875C13 12.3219 12.841 12.7046 12.5231 13.0231C12.2051 13.3416 11.8224 13.5005 11.375 13.5H1.625Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                            <a href="" class="action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24"
                                    viewBox="0 0 25 24" fill="none">
                                    <rect x="0.5" width="24" height="24" rx="2"
                                        fill="white" />
                                    <path
                                        d="M9.0625 18C8.68438 18 8.36079 17.8696 8.09175 17.6087C7.82271 17.3478 7.68796 17.0338 7.6875 16.6667V8H7V6.66667H10.4375V6H14.5625V6.66667H18V8H17.3125V16.6667C17.3125 17.0333 17.178 17.3473 16.9089 17.6087C16.6399 17.87 16.3161 18.0004 15.9375 18H9.0625ZM15.9375 8H9.0625V16.6667H15.9375V8ZM10.4375 15.3333H11.8125V9.33333H10.4375V15.3333ZM13.1875 15.3333H14.5625V9.33333H13.1875V15.3333Z"
                                        fill="#6B6B6B" />
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>

            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user_dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tax_dax.com\resources\views/user_dashboard/layouts/document-center.blade.php ENDPATH**/ ?>